"use strict"

Object.defineProperty(exports, "__esModule", { value: true })

const ALL_WA_PATCH_NAMES = ['critical_block', 'critical_unblock_low', 'regular_high', 'regular_low', 'regular']

module.exports = {
  ALL_WA_PATCH_NAMES
}